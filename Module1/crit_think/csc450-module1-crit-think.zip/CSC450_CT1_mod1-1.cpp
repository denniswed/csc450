/* Simple Program with a few Errors for Correction
   Please be sure to correct all outlined errors.
    - Missing ending comment characters for header comments - adding
    - Missing comment characters for Main Function label - adding
    - conio.h is not needed, nor findable - removing
    - Missing comment for namespace declaration - removing
    - pulling in an entire namespace is not best practice - removing
    - useless comments in main function - removing
*/

#include <iostream>

// Main Function
int main() {

  // Standard Ouput Statement
  std::cout << "Welcome to this C++ Program" << std::endl;

  std::cout << "I have corrected all errors for this program." << std::endl;

  // Wait For Output Screen

  // Main Function return Statement
  return 0;
}
