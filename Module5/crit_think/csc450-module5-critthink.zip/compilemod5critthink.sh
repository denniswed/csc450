#!/bin/bash

# Improved version (requires C++17 for filesystem)
g++ -std=c++17 -Wall -Wextra -Wpedantic -g mod5-critthink-improved.cpp -o mod5-critthink-improved